<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Inventry | Dashboard</title>
      <!-- Tell the browser to be responsive to screen width -->
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <!-- Bootstrap 3.3.6 -->
      <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
      <!-- Ionicons -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
      <!-- DataTables -->
      <link rel="stylesheet" href="/plugins/datatables/dataTables.bootstrap.css">
      <!-- Theme style -->
      <link rel="stylesheet" href="/dist/css/AdminLTE.min.css">
      <link rel="stylesheet" href="/plugins/select2/select2.min.css">
      <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
      <link rel="stylesheet" href="/dist/css/skins/_all-skins.min.css">
      <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
   @include('header')
   <!-- Left side column. contains the logo and sidebar -->
   @include('nav')
   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
         <h1>
            Add Order
            <small>Order</small>
         </h1>
         <ol class="breadcrumb">
            <li><a href="/"><i class="fa fa-dashboard"></i>Home</a></li>
            <li class="active">Order</li>
            <li class="active">Add Order</li>
         </ol>
      </section>
      <!-- Main content -->
      <section class="content col-md-8">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title">Select Product</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
               <table id="example1" class="table table-bordered table-striped tableOrder">
                  <thead>
                     <tr>
                        <th>S.No</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr id="productSelect">
                        <td width="10%" class="counter">1</td>
                        <td width="35%">
                           <select class="form-control select2 productSelct">
                              <option selected="selected">Alabama</option>
                              <option>Alaska</option>
                              <option>California</option>
                              <option>Delaware</option>
                              <option>Tennessee</option>
                              <option>Texas</option>
                              <option>Washington</option>
                           </select>
                        </td>
                        <td width="15%"><input type="text" width="15px;" name="quantity"></td>
                        <td width="20%"> 4</td>
                        <td width="10%">X</td>
                        <td>
                           <a  class="addProductRow">
                           <i class="glyphicon glyphicon-plus"></i>  
                           </a> 
                           <a href="">
                           <i class="glyphicon glyphicon-remove"></i>  
                           </a>                             
                        </td>
                     </tr>
                  </tbody>
               </table>
            </div>
            <!-- /.box-body -->
         </div>
      </section>
      <section class="content col-md-4">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title">Order Summary</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
               <div class="box-background">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="form-group">
                           <label class="col-sm-5 control-label">Order No.</label>
                           <div class="col-sm-7">
                              <input value="1031" disabled="" class="form-control " type="text">
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <form method="post" action="http://easy-inventory.codeslab.net/admin/order/save_order">
                  <div class="box-background" id="order">
                     <div class="box-body" style="border-top: 0px solid rgb(204, 204, 204);">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="form-group">
                                 <label class="col-sm-5 control-label">Sub Total</label>
                                 <div class="col-sm-7">
                                    <input value="40,800.00" disabled="" class="form-control unite" type="text">
                                 </div>
                              </div>
                              <br>
                              <br>
                              <div class="form-group">
                                 <label class="col-sm-5 control-label">Tax</label>
                                 <div class="col-sm-7">
                                    <input value="2,040.00" disabled="" class="form-control unite" type="text">
                                 </div>
                              </div>
                              <div class="col-md-12" style="margin-bottom: 5px"></div>
                           </div>
                        </div>
                     </div>
                     <!-- /.box-body -->
                  </div>
                  <div class="box-body" style="border-top: 0px solid rgb(204, 204, 204);">
                     <div class="row">
                        <div class="col-md-12">
                           <div class="form-group">
                              <label class="col-sm-4 control-label" style="padding-top: 5px; font-size: 15px">Grand Total :</label>
                              <div class="col-sm-8">
                                 <h2>$ 42,840.00</h2>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="box-body" style="border-top: 0px solid rgb(204, 204, 204);">
                     <div class="row">
                        <div class="col-md-12">
                           <button type="submit" id="btn_order" class="btn bg-navy btn-block btn-flat ">Submit Order
                           </button>
                        </div>
                     </div>
                  </div>
                  <!-- hidden field -->
                  <input name="customer_id" value="" type="hidden">
                  <input value="1031" name="order_no" type="hidden">
                  <input value="42840" name="grand_total" type="hidden">
                  <input value="2040" name="total_tax" type="hidden">
                  <input value="" name="discount_amount" type="hidden">
                  <input value="0" name="discount" type="hidden">
               </form>
            </div>
         </div>
      </section>
      <!-- /.content -->
   </div>
   <!-- /.content-wrapper -->
   <footer class="main-footer">
      <div class="pull-right hidden-xs">
         <b>Version</b> 2.3.8
      </div>
      <strong>Copyright &copy; 2014-2017 <a href="http://fustech.net">Fusion Technologies</a>.</strong> All rights
      reserved.
   </footer>
   <!-- Control Sidebar -->
   <!-- /.control-sidebar -->
   <!-- Add the sidebar's background. This div must be placed
      immediately after the control sidebar -->
   <!-- ./wrapper -->
   <!-- jQuery 2.2.3 -->
   <script src="/plugins/jQuery/jquery-2.2.3.min.js"></script>
   <!-- Bootstrap 3.3.6 -->
   <script src="/bootstrap/js/bootstrap.min.js"></script>
   <script src="/plugins/select2/select2.full.min.js"></script>
   <!-- DataTables -->
   <!-- <script src="/plugins/datatables/jquery.dataTables.min.js"></script> -->
   <!-- <script src="/plugins/datatables/dataTables.bootstrap.min.js"></script> -->
   <!-- SlimScroll -->
   <script src="/plugins/slimScroll/jquery.slimscroll.min.js"></script>
   <!-- FastClick -->
   <script src="/plugins/fastclick/fastclick.js"></script>
   <!-- AdminLTE App -->
   <script src="/dist/js/app.min.js"></script>
   <!-- AdminLTE for demo purposes -->
   <script src="/dist/js/demo.js"></script>
   <!-- page script -->
   <script>
      $(document).ready(function() {
      
          $('.box-body').css({"border-top":"0px solid #ccc"});
      
         
      
      });
      
   </script>
   <script>
       var selectOne = $(".select2").select2();
      var counter = 1;
       $('.addProductRow').on('click', function(){
         selectOne.select2("destroy");
         counter++;
         console.log(counter);
           var clonedDiv = $('#productSelect').clone(true).find("input:text").val("").end();
           selectOne.select2();
           clonedDiv.insertAfter('.tableOrder tr:last').find('select').select2();
      
       });
   </script>
   </body>
</html>