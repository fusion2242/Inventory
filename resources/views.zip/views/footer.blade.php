<footer class="main-footer">
      <div class="pull-right hidden-xs">
         <b>Version</b> 2.3.8
      </div>
      <strong>Copyright 20XX-20XX TFO'S Group All rights
      reserved.
   </footer>