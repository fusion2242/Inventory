<footer class="main-footer">
      <div class="pull-right hidden-xs">
         <b>Version</b> 2.3.8
      </div>
      <strong>Copyright &copy; 2014-2017 <a href="http://fustech.net">Fusion Technologies</a>.</strong> All rights
      reserved.
   </footer>