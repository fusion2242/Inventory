<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    function viewaddorder()
    {
    	return view('order.add');
    }
    function viewmanageorder()
    {
    	return view('order.manage');
    }
    function viewmanageinvoice()
    {
    	return view('order.invoice');
    }
}
